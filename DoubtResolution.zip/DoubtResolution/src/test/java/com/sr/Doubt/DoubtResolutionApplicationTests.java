package com.sr.Doubt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoubtResolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
