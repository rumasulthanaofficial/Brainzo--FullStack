package com.sr.doubt.service;


import com.sr.doubt.model.Doubt;
import com.sr.doubt.repository.DoubtRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoubtService {

    @Autowired
    private DoubtRepository doubtRepository;

    // Save a new doubt
    public Doubt postDoubt(Doubt doubt) {
        return doubtRepository.save(doubt); // Save and return the saved doubt
    }

    // Get all doubts
    public List<Doubt> getAllDoubts() {
        return doubtRepository.findAll();
    }

    // Add a reply to a specific doubt
    public Doubt addReply(Long id, String reply, String mentorName) {
        Doubt doubt = doubtRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doubt not found"));
        doubt.getReplies().add(reply);  // Add the reply to the list
        doubt.setMentorName(mentorName); // Set the mentor's name
        return doubtRepository.save(doubt);  // Save the updated doubt
    }
}

