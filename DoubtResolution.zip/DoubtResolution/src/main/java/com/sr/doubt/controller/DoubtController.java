package com.sr.doubt.controller;


import com.sr.doubt.model.Doubt;
import com.sr.doubt.service.DoubtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doubts")
@CrossOrigin(origins = "http://localhost:4200") // Adjust the port based on your frontend
public class DoubtController {

    @Autowired
    private DoubtService doubtService;

    // Post a new doubt
    @PostMapping
    public ResponseEntity<Doubt> postDoubt(@RequestBody Doubt doubt) {
        Doubt savedDoubt = doubtService.postDoubt(doubt);
        return ResponseEntity.status(201).body(savedDoubt); // Return 201 CREATED
    }

    // Get all posted doubts
    @GetMapping
    public ResponseEntity<List<Doubt>> getAllDoubts() {
        return ResponseEntity.ok(doubtService.getAllDoubts());
    }

    // Post a reply to a specific doubt
    @PostMapping("/{id}/reply")
    public ResponseEntity<Doubt> postReply(@PathVariable Long id, @RequestBody ReplyRequest replyRequest) {
        Doubt updatedDoubt = doubtService.addReply(id, replyRequest.getReply(), replyRequest.getMentorName());
        return ResponseEntity.ok(updatedDoubt);
    }

    // ReplyRequest class to handle reply and mentor details
    public static class ReplyRequest {
        private String reply;
        private String mentorName;

        // Getters and Setters
        public String getReply() {
            return reply;
        }

        public void setReply(String reply) {
            this.reply = reply;
        }

        public String getMentorName() {
            return mentorName;
        }

        public void setMentorName(String mentorName) {
            this.mentorName = mentorName;
        }
    }
}

