package com.sr.doubt.repository;

import com.sr.doubt.model.Doubt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoubtRepository extends JpaRepository<Doubt, Long> {
}

