package com.sr.doubt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

 

@SpringBootApplication
public class DoubtResolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoubtResolutionApplication.class, args);
	}

}
