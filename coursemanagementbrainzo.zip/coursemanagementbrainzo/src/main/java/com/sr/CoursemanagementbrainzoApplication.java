package com.sr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


 


@SpringBootApplication
public class CoursemanagementbrainzoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursemanagementbrainzoApplication.class, args);
	}

}
