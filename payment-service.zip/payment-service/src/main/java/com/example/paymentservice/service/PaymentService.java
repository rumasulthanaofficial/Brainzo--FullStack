package com.example.paymentservice.service;

import com.example.paymentservice.model.Payment;
import com.example.paymentservice.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Payment processPayment(Payment payment) {
        // Simulate backend payment processing logic (e.g., call Razorpay API)

        // For demonstration, let's mark the payment as successful
        payment.setStatus("success");

        return paymentRepository.save(payment);
    }
}

