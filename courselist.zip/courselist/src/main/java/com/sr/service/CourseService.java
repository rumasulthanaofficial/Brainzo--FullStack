package com.sr.service;

import com.sr.model.Course;
import com.sr.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    // Fetch all courses
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    // Fetch a course by its ID (with features)
    public Course getAllData(int id) {
        return courseRepository.findById(id);//.orElse(null);  // Fetch course by ID
    }

    // Save a new course
    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }
}
