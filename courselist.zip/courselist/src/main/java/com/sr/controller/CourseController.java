package com.sr.controller;

	import com.sr.model.Course;
	import com.sr.service.CourseService;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.*;

	import java.util.List;

	@RestController
	@RequestMapping("/api/courses")
	@CrossOrigin(origins = "http://localhost:4200")  // Allow cross-origin requests from Angular app
	public class CourseController {

	    @Autowired
	    private CourseService courseService;

	    // Fetch all courses
	    @GetMapping
	    public List<Course> getAllCourses() {
	        return courseService.getAllCourses();
	    }

	    // Fetch course features by course ID
	    @GetMapping("/getFeatures/{id}")
	    public Course getCourseFeatures(@PathVariable int id) {
	        return courseService.getAllData(id);  // Assuming getAllData returns Course with features
	    }

	    // Create a new course (if needed)
	    @PostMapping
	    public Course createCourse(@RequestBody Course course) {
	        return courseService.saveCourse(course);
	    }
	}





