package com.sr.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

	@Bean
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes()
				.route("COURSELIST", r -> r.path("/api/courses/**")
						.uri("lb://COURSELIST"))
				.route("COURSEMANAGEMENTBRAINZO", r -> r.path("/api/courses/**")
						.uri("lb://COURSEMANAGEMENTBRAINZO"))
				.route("DOUBTRESOLUTION", r -> r.path("/api/doubts/**")
						.uri("lb://DOUBTRESOLUTION"))
				.route("PAYMENTSERVICE", r -> r.path("/api/payments/data/**")
						.uri("lb://PAYMENTSERVICE"))
				.route("BRAINZO", r -> r.path("/api/auth/**")
						.uri("lb://BRAINZO"))
				.build();
				 
	}
}