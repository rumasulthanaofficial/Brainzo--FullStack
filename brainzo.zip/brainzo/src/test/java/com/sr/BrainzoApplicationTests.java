package com.sr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainzoApplicationTests {

	@Test
	void contextLoads() {
	}

}
