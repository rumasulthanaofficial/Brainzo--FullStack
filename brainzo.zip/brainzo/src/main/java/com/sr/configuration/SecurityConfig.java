package com.sr.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // Define the security filter chain with role-based access
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()  // Disable CSRF protection
            .authorizeHttpRequests((authz) -> authz
                .requestMatchers("/api/auth/**").permitAll() // Allow public access to authentication endpoints
                .requestMatchers("/api/user/**").hasRole("USER") // Only students can access student endpoints
                .requestMatchers("/api/mentor/**").hasRole("MENTOR")   // Only mentors can access mentor endpoints
                .anyRequest().authenticated() // All other requests require authentication
            );
        return http.build();
    }

    // Define the password encoder (BCrypt)
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Define the in-memory users and their roles
    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user = User.withUsername("user")
            .password(passwordEncoder().encode("USER"))
            .roles("USER")
            .build();

        // Mentor user with the role "MENTOR"
        UserDetails mentorUser = User.withUsername("mentorUser")
            .password(passwordEncoder().encode("mentorPass"))
            .roles("MENTOR")
            .build();

        // In-memory user details manager
        return new InMemoryUserDetailsManager(user, mentorUser);
    }

    // Define the authentication manager
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
            http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
        return authenticationManagerBuilder.build();
    }
}